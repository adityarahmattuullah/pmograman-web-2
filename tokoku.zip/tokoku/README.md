Halo temen-temen...

kali ini saya akan membagikan aplikasi untuk mengatur toko. lebih tepatnya yaitu untuk mengatur stok, laporan penjualan, dan laporan keuntungan sebuah toko. selain itu, ada berbagai fitur yang disediakan aplikasi ini. untuk lebih jelasnya, dapat dilihat pada daftar di bawah ini.

Fitur aplikasi TOKOKU.
Login dan logout.



Aplikasi ini sudah ada fitur keamaanan login dan logout. agar aplikasi ini tidak digunakan oleh orang lain.
Management Barang.

aplikasi ini dapat mengatur barang. yaitu menambah jenis barang dan menghapusnya bila ada perubahan atau barang sudah tidak dijual lagi.

Management User.

Aplikasi ini bisa digunakan oleh banyak user. dengan jabatan yang berbeda. yaitu admin dan karyawan.

Transaksi.

Aplikasi ini bisa digunakan untuk fitur kasir atau transaksi. dimana bisa memilih barang apa aja yang akan di beli. dengan total harga yang dapat ditampilkan.

Management Stok.

Stok barang juga bisa diatur di aplikasi ini. bisa menambah, atau mengurangi stok secara manual dengan alasan tertentu.

Laporan Penjualan/keuntungan.

Laporan penjualan per hari, perbulan, bahkan pertahun bisa kita lihat pada aplikasi ini. dengan hanya menyesuaikan tanggal yang kita butuhkan saja.

Jabatan user. karyawan dan admin.
jabatan karyawan dan admin disini hanya pada management user. dimana admin dapat menamb dan menghapus user. sedangkan karyawan tidak dapat melakukannya.

